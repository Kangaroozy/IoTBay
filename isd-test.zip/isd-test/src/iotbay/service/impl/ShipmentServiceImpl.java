package iotbay.service.impl;


import iotbay.dao.ShipmentDao;
import iotbay.model.Shipment;
import iotbay.service.ShipmentService;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;


public class ShipmentServiceImpl implements ShipmentService {

    private final ShipmentDao shipmentDao = new ShipmentDao();



    public Shipment queryById(Integer id) throws SQLException {
        return this.shipmentDao.queryById(id);
    }



    public Shipment insert(Shipment shipment) throws SQLException {
        this.shipmentDao.insert(shipment);
        return shipment;
    }

    public Shipment update(Shipment shipment) throws SQLException {
        this.shipmentDao.update(shipment);
        return this.queryById(shipment.getId());
    }

    public boolean deleteById(Integer id) throws SQLException {
        return this.shipmentDao.deleteById(id) > 0;
    }


    public Map<String, Object> findAllByPage(Map<String, Object> params) throws SQLException {
        return shipmentDao.queryAll((Shipment) params.get("entity"), Integer.parseInt(params.get("pageSize").toString()), Integer.parseInt(params.get("pageNum").toString()));
    }

    @Override
    public List<Shipment> findAll(Shipment shipment) throws SQLException {
        return shipmentDao.findAll(shipment);
    }
}
