/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iotbay.controller;

import iotbay.model.Shipment;
import iotbay.model.dao.DBShipmentManager;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.UUID;

/**
 * create shipment servlet.
 *
 * a shipment id linked to order id
 *
 * @author shu
 */
public class CreateShipmentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        DBShipmentManager smanager = (DBShipmentManager) session.getAttribute("shipmentManager");

        String unitnumber = req.getParameter("unitnumber");
        String streetname = req.getParameter("streetname");
        String suburb     = req.getParameter("suburb");
        String postcode   = req.getParameter("postcode");
        String state      = req.getParameter("state");
        String userid     = req.getParameter("userid");

        Shipment shipment = new Shipment();

        shipment.setUnitNumber(unitnumber);
        shipment.setStreetName(streetname);
        shipment.setSuburb(suburb);
        shipment.setPostCode(postcode);
        shipment.setState(state);
        shipment.setUserid(userid);
        shipment.setShipmentDate(new Date());

        try {
            smanager.saveShipment(shipment);
            req.getRequestDispatcher("Shipment.jsp").forward(req, resp);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
