/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Reyvaldo
 * Created: Apr 23, 2021
 */

INSERT INTO IOTUSER.CUSTOMER (FIRSTNAME, LASTNAME, EMAIL, PASSWORD, GENDER, ADDRESS, PHONENUMBER) 
	VALUES  ('Fern', 'Hewitt', 'fern123@gmail.com', 'fern123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Geoffrey', 'Dawson', 'geoffrey123@gmail.com', 'geoffrey123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Trix', 'Mendez', 'trix123@gmail.com', 'trix123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Constant', 'Rowse', 'constant123@gmail.com', 'constant123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Camilla', 'Hubbard', 'camilla123@gmail.com', 'camilla123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Tristan', 'Clark', 'tristan123@gmail.com', 'tristan123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Lincoln', 'Weaver', 'lincoln123@gmail.com', 'lincoln123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Erin', 'Ward', 'erin123@gmail.com', 'erin123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Jeff', 'Carpenter', 'jeff123@gmail.com', 'jeff123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Vernon', 'Joseph', 'vernon123@gmail.com', 'vernon123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Tuesday', 'Marshman', 'tuesday123@gmail.com', 'tuesday123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Kenneth', 'Poole', 'kenneth123@gmail.com', 'kenneth123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Fiona', 'Shorts', 'fiona123@gmail.com', 'fiona123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Victoria', 'Hodgson', 'victoria123@gmail.com', 'victoria123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Eloise', 'Holt', 'eloise123@gmail.com', 'eloise123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Marshall', 'Tucker', 'marshall123@gmail.com', 'marshall123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Nigel', 'Pascall', 'nigel123@gmail.com', 'nigel123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Jade', 'Schneider', 'jade123@gmail.com', 'jade123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Simona', 'Stephens', 'simona123@gmail.com', 'simona123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Albert', 'Wallaker', 'albert123@gmail.com', 'albert123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006');


INSERT INTO IOTUSER.STAFF (FIRSTNAME, LASTNAME, EMAIL, PASSWORD, GENDER, ADDRESS, PHONENUMBER) 
	VALUES  ('Ollie', 'Hicks', 'ollie123@gmail.com', 'ollie123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Echo', 'Harper', 'echo123@gmail.com', 'echo123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Teri', 'Davidson', 'teri123@gmail.com', 'teri123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Jocelyn', 'Bacchus', 'jocelyn123@gmail.com', 'jocelyn123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Lois', 'Bowen', 'lois123@gmail.com', 'lois123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Milton', 'Rehbein', 'milton123@gmail.com', 'milton123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Alanna', 'Meyer', 'alanna123@gmail.com', 'alanna123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Astrid', 'Barnes', 'astrid123@gmail.com', 'astrid123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Brooke', 'Lipsey', 'brooke123@gmail.com', 'brooke123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Nelson', 'Brewer', 'nelson123@gmail.com', 'nelson123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Albion', 'Harding', 'albion123@gmail.com', 'albion123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Marc', 'Farmer', 'marc123@gmail.com', 'marc123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Ivory', 'Mendez', 'ivory123@gmail.com', 'ivory123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Thomasina', 'Watts', 'thomasina123@gmail.com', 'thomasina123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Iris', 'Carline', 'iris123@gmail.com', 'iris123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Ash', 'Moore', 'ash123@gmail.com', 'ash123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Russell', 'Floyd', 'russell123@gmail.com', 'russell123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Goodwin', 'Bowen', 'goodwin123@gmail.com', 'goodwin123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Gerry', 'Schuman', 'gerry123@gmail.com', 'gerry123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006'),
                ('Stewart', 'Moody', 'stewart123@gmail.com', 'stewart123', 'Male', '105§Quay St§Ultimo§NSW§2000', '0450321006');

INSERT INTO IOTUSER.PRODUCT ("NAME", CATEGORY, PRICE, DESCRIPTION, STOCK) 
	VALUES ('DHT11', 'temperature/humidity', 3.45, 'The DHT11 sensor can measure humidity as well as temperature. Only one GPIO is used. is only able to measure areas of 20-90% humidity and an error margin of 5%.', 5),
               ('DHT22', 'temperature/humidity', 4.0, 'The DHT22 sensor can measure humidity as well as temperature. Only one GPIO is used. is only able to measure all areas of humidity and an error margin of 2%.', 6),
               ('DS18B20', 'temperature', 4.0, 'The DS18B20 represents a very simple sensor. These Raspberry Pi sensors are addressed via the so-called 1-wire bus. An advantage is that many different 1-wire components can be connected in series and read out by a single GPIO. However, these modules can not measure additional information such as humidity and / or air pressure. The DS18B20 is particularly suitable for outdoor use, as there are also water resistant versions available. With a measuring range of -55Â°C to +125Â°C it is well suited even for non-everyday applications.', 7),
               ('DS18S20', 'temperature', 4.0, 'DS18S20 represents a very simple sensor. These Raspberry Pi sensors are addressed via the so-called 1-wire bus. An advantage is that many different 1-wire components can be connected in series and read out by a single GPIO. However, these modules can not measure additional information such as humidity and / or air pressure.', 5),
               ('BMP180 Barometer', 'air pressure/temperature', 6.0, 'The determination of the air pressure can be meaningful in weather stations and similar projects. This is best done using the BMP180, which is controlled via I2C on the Raspberry Pi. In addition to the air pressure, the temperature can be read out as well as the altitude. However, the last value is not very accurate. If you need the height, you should read the values with a GPS receiver.', 5),
               ('Moisture Sensor', 'humidity sensor', 5.0, 'This analogue humidity sensor finds an excellent place in automatic irrigation systems. It is placed in the ground and measures the humidity by current flowing between the strands. The more humid the earth in between, the higher the (analog) signal. In order to read the value with the Raspberry Pi, the MCP3008 is needed (Arduinos can recognize analog signals directly).', 65),
               ('Giess-o-Mat', 'humidity sensor', 7.0, 'A problem with analog moisture sensors is that they erode over time and are not always very precise. Capacitive sensors prevent these problems. The relative humidity is calculated by means of the frequency. However, a frequency divider is also suitable for use with the Raspberry Pi.', 12),
               ('MQ-2 Gas Sensor', 'gas sensor', 2.0, 'The MQ gas sensors can detect different gases at room temperature. Depending on the model, other gases are supported. The MQ-2 can recognize methane, butane, LPG and smoke, the MQ3 detects, for example, alcohol, ethanol and smoke, etc. You can find a list of all MQ sensors and their supported gases here. You should take care that these sensors can be very hot and they should not be touched directly. Since these modules also work analogically with 5V, you need also a MCP3008 as well as a 3.3V-5V TTL to read the signals.', 124),
               ('PIR Motion Sensor', 'motion sensor', 2.0, 'The PIR motion sensor has some advantages over other similar products: besides the low price, a signal is sent only if something moves. This allows you to wait for signal flanks using the GPIOs. In addition, a resistance can be varied so that a signal is only sent when the movement is close, or changes that are already far away are perceived. In addition to outdoor projects, the PIR can also be used in buildings â whether to activate the lighting or, as I use it, to turn on my touch screen for home automation as soon as someone approaches it.', 123),
               ('HC-SR04 ultrasonic sensor', 'ultrasonic sensor', 3.0, 'The HC-SR04 sensor is not a distance / motion detector, but an ultrasonic sensor. Through a small trick it is nevertheless possible to measure distances. By measuring the time elapsed between transmitting and receiving an ultrasound signal, you can derive the distance as the sound velocity in the air is known. In the tutorial I explain the details. The wide opening angle is an aspect which, however, must be considered: since the ultrasound propagates not only on a straight line, but at an angle of about 15Â°, the signal is first reflected from the nearest point in this area â which can be also an external point. As a rough estimate, or for moving robots, it is nevertheless useful, also because of the low price.', 124),
               ('Magnetic Switch / Reed Relay', 'sensor', 3.0, 'By means of magnetic sensors / reed relay, you can check for binary states. The magnetic relay is opened as soon as a magnet is in the vicinity. Otherwise the access is closed. So if voltage is then passed through, you can check the condition. In particular, these magnetic sensors are suitable for inspecting windows and doors by mounting them on the frame and checking whether the door / window is open or closed.', 12341),
               ('GP2Y0A02YK', 'infrared sensor', 12.0, 'With the GP2Y0A02YK infrared distance meter, much more accurate measurements can be performed, as with e.g. the HC-SR04. The module is limited to a range of 20-150cm. Alternatively, the similar sensor GP2Y0A710K0F can be used, which has a range of 100 to 500cm.', 512),
               ('RFID-RC522 â Inductive RFID card reader', 'rfid', 5.0, 'The RFID-RC522 is a card reader for check cards. A signal is transmitted via the SPI data bus as soon as a card approaches on a few centimeters. Each card has a different code, which you can read out. Thus, for example, locks and / or doors could be realized, which open without contact â sesame open up', 124),
               ('GPS NEO-6M Module', 'gps', 10.0, 'The most common and best known GPS receiver is the NEO-6M module. All GPS position data can be determined with the help of the orbiting satellites. In addition, it is compatible with the Raspberry Pi packages minicom and gpsd, which makes reading the coordinates very easy.', 124),
               ('USB GPS Receiver', 'gps', 15.0, 'As an alternative to GPS modules which are connected via the GPIOs, USB GPS receivers can also be used. Those have the advantage that (almost) all are compatible with Windows, Linux and Mac and no additional connection is necessary. On the other hand, these modules are usually more expensive, but they are not inferior in terms of accuracy. It is therefore an individual question, which type of receiver is preferred.', 125),
               ('MPU-6050 Gyroscope', 'gyroscope', 4.0, 'A gyroscope (circular instrument) is used to detect the rotation along the three axes. The MPU 6050 sensor also contains an acceleration sensor. This module can be used e.g. in robot arms to determine the angle of rotation.', 351),
               ('HMC5883L / GY-271 Compass', 'compass', 5.0, 'As with analogue compasses, the directional display can also be read digitally. The HMC5883L sensor, which is read out via I2C, which returns an angle in radians, is suitable for this purpose. As with a normal compass, the value can be confounded by metal objects nearby', 124),
               ('DS1307 RTC', 'clock', 3.0, 'If the Raspberry Pi is connected to the Internet, it can request the exact time. This could be a problem in applications where no (permanent) Internet connection is given, but the date and the exact time is important (car PC, weather station, etc.). A so-called Realtime Clock (RTC) module can help: Once initialized, it saves the current time â even if the power supply is not present â due to the small battery. On computer mainboards such a module is installed, which is why the time of the computer does not have to be re-adjusted every time you restart. Since the Raspberry Pi / Arduino does not carry an RTC module from within, this can be retrofitted.', 213),
               ('433 MHz Set', 'radio', 3.0, 'One of the simplest method to transmit signals via radio are 433 MHz transmitter and receiver. Since these sets are very cheap, they are used in many projects. So you can for example let several Raspberry Piâs communicate with each other. Many other devices work also with 433 MHz radio signals, such as garage doors or radio controlled outlets, and these codes can be recorded and sent for specific tasks.', 142),
               ('2.4 GHz NRF24L01+ Modul', 'wireless', 4.0, 'A more advanced method for wireless communication is the use of the 2.4 GHz frequency. The advantages compared to the 433 MHz transmission rate are mainly that a larger amount of data can be transferred at once. Thus, whole sentences and commands can be sent with a signal / data package. A second Raspberry Pi or an Arduino can also be equipped with a 2.4 GHz receiver / transmitter and thus receive commands from a âbase stationâ and send back data.', 213),
               ('Radio controlled outlets / Power sockets', 'radio/power', 15.0, 'In the field of home automation, wireless sockets are almost a standard. The vast majority of these devices work with 433 MHz radio signals. By reading the codes of the remote control with a receiver on the Raspberry Pi, one can switch these radio sockets individually. There are different models, usually pure switchable radio sockets, but also (dimmable) lamp sockets are offered. You should pay attention to one criterion: There are models with a so-called âgenericâ code, i.e. on these models the code is randomly generated and changes. These frequencies are hard to read out. On the other hand, those sockets, in which the code is freely selectable, are very easy to control.', 123),
               ('Si4703 Radio receiver', 'radio', 10.0, 'The Si470x module offers the option to upgrade the Pi to a radio receiver, which can be very interesting in Car PCs or Raspberry Pi Jukeboxes. As with conventional radios, the frequency and certain options can be adjusted (via software). If that is not enough, you can also use your Pi as a radio station.', 123),
               ('Bluetooth Adapter', 'bluetooth', 10.0, 'The Raspberry Pi has not always had an integrated Bluetooth module. Before the model 3 was published, neither Bluetooth nor WiFi modules were onboard. The inexpensive Zero model also comes without a Bluetooth adapter. Since almost every mobile phone supports this communication method as standard, it is so easy to exchange pictures and other files between the smartphone and Raspberry Pi. Other projects such as controlling the Pi via Bluetooth commands are also possible.', 123),
               ('GSM Surfstick', 'internet', 30.0, 'The Raspberry Pi is used in many outdoors projects, e.g. as a weather station or for monitoring certain things. However, even if no (or only a weak) WIFI signal is available, many functions are restricted. If you still want to have access to the Pi and also receive the data of such an outside project, an Internet connection is necessary. The mobile surfsticks, which are also often available as gifts for data rate contracts, can be useful. With such a stick and a SIM card with data volume, the Pi can be permanently online. In addition, it is also possible to use the stick to send and receive SMS, for example to remotely control the Raspberry Pi by a mobile phone.', 124),
               ('Infrared diodes', 'IR', 3.0, 'Most remote controls use infrared LEDs to transmit signals. These codes can be read and stored easily with an infrared receiver. With the program LIRC, it is also possible to send those codes with an IR transmitter diode. For example, a TV can be controlled with the Raspberry Pi. In addition, there are also IR LEDs, which can be used as a light barrier.', 124),
               ('Laser Module', 'laser', 2.0, 'Although standard laser modules do not have great functionality (can be switched on and off), they are used in various interesting projects. Thus, for example, there are projects of distance measuring devices, which are using a camera and a laser module. The laser is switched on and off very quickly and pictures are recorded. The distance can then be calculated by means of the beam set. Due to the exchangeable mirrors at the head of the laser modules, different patterns such as grids are possible.', 124),
               ('Servo Motors', 'servo/motor', 3.0, 'Unlike ordinary motors, servo motors can be individually controlled. Only the indication of the angle of rotation for moving the motor is necessary. PWM (pulse width modulation) signals are sent to the motor. The Raspberry Pi can use this method of transmission. Using the Python GPIO library or WiringPi is particularly easy.', 213),
               ('28BYJ-48 Stepper Motor', 'stepper/motor', 3.0, 'Step motors are motors that can âgoâ a certain number of steps in one revolution. Two electromagnets are built in, which move the axis through different poles. How the polarity looks like is written in the data sheet of the motor. One of the most popular stepping motors (because it has a lot of steps and is nevertheless cheap) is the model 28BYJ-48. This motor has 512 steps, each step consisting of 8 sequences. This means that a full revolution has 4096 steps (or one step is made per 0.087Â°).', 412),
               ('PCA9685 Servo Board', 'servo', 5.0, 'Using PWM, servos can be controlled directly from the Raspberry Pi. However, as soon as you want to control several servo motors, either the GPIOs can become scarce, or you need more power. The PCA9685 servo driver board is ideally suited for this purpose because you can control up to 16 motors per board via I2C. And not enough. It is even possible to connect several boards one after the other. In addition, an external power supply can be easily connected. If you want to use a robot arm, for example, this is the optimal board.', 124),
               ('ULN2003', 'stepper/motor/driver', 4.0, 'Those 28BYJ-48 stepping motors are often supplied with a driver board. The supplied board usually has a ULN2003 IC, which holds the voltage for the 5V motor, but can be controlled with 3.3V. This is important because the GPIOs are protected and no transistor or relay is needed.', 2412),
               ('L293D', 'stepper/motor/driver', 2.0, 'An alternative driver IC is the L293D. The advantage of this module, compared to the ULN2003, is that it can also be used with higher voltages than 5V. Because many alternative stepping motors (e.g., fewer steps for faster rotation or higher pulling force) require more than 5V, they must be powered by an external current source. The L293 IC is ideal for controlling these motors. By the way, it is even possible to control two motors simultaneously (individually).', 412),
               ('A4988', 'stepper/motor/driver', 6.0, 'This IC is another way to control step motors. It is especially designed for motors in 3D printers and can withstand voltages of 8V to 35V with a current of one amp. Since it can get hot very quickly, a cooling sink is included on the chip of the breakout board.', 512),
               ('MCP3008 Analog-to-digital converter', 'analog', 5.0, 'Unlike the Arduino, the Raspberry Pi does not have its own analog IO pins. This means that you can not simply read out analog modules. The MCP3008 module helps you: It makes it possible to use analog modules with the Raspberry Pi and therefore this digital converter is required for all analog modules on the Raspberry Pi.', 412),
               ('Joystick', 'analog/input', 6.0, 'One of these analog modules is a 2-axis joystick. Two potentiometers (see below) for X and Y axes are installed, which allow more or less voltage to pass through the movement. If one converts the analog value into a digital, one gets numbers between 0 (no voltage) and 1023 (full voltage). In the center, a digital value of approx. 512 is returned on both axes.', 124),
               ('Potentiometer / Rotary Switch', 'analog/input', 4.0, 'Potentiometers are basically rotatable resistors. You can change the resistor value easily by rotating the control knob. Each module has a maximum resistance (minimum is zero). In addition to joysticks, potentiometers can also be found e.g. in brightness or volume controllers.', 73),
               ('Raindrop Sensor', 'water sensor/analog', 2.0, 'In order to determine whether it is raining or how much rain is present, a rainwater sensor can be used. It works analogously and can be read with the MCP3008. Depending on the amount of water, the capacitance is increased and a stronger analog signal is read out.', 125),
               ('Heartbeat / Pulse Sensor', 'analog/sensor', 7.0, 'With a pulse sensor, the heart rate can be read out on the Raspberry Pi. The analogously detected value changes, depending on the pulse beat. This is again converted with an ADC and the pulse is determined on the basis of the last measured values.', 3161),
               ('Relays', 'power/current', 4.0, 'The GPIOs of the Raspberry Pi work with 3.3V, although it also has a 5V pin. However, many devices require a higher voltage. In order not to combine the circuits, one can use relays, which are basically switches. This has the advantage that you can also switch circuits with higher voltages with the Raspberry Pi, without risking something.', 512),
               ('LM2596 Buck Converter / Step Down Module', 'power/current', 3.0, 'With the LM2596 (and similar) modules, higher voltages can be regulated downwards. For example, you can regulate the current of (rechargeable) batteries to the required 5V USB input voltage. However, no alternating current (AC) is allowed, but only direct current (DC), as supplied by batteries.', 214),
               ('3.3V â 5V TTL I2C Logic Level Converter', 'power/current', 2.0, 'Some modules and sensors for the Arduino output 5V signals, but this would destroy the GPIOs, since those work with 3.3V. Here, a level converter can be used to further control the signals. It is important to ensure that bi-directional level converters are purchased so that you can send and receive signals as well.', 6123),
               ('Official 7â³ Touchscreen', 'display', 75.0, 'In September 2015 the Raspberry Pi Foundation introduced the official touch screen display after a long time. It has 7â³ at a resolution of 800Ã480 pixels. The 10 point capacitive touchscreen is connected through the DSI port and doesnât occupy any USB ports or GPIOs. The inital startup is very easy and you even donât need additional software (only an actual version of Raspbian or NOOBS).', 142),
               ('3.2â³ Touchscreen', 'display', 10.0, 'Not everyone needs 7 âor larger displays, sometimes a smaller touch screen is also enough, but the choice is relatively large. Sizes between 2.4 and 4.3 inches are very common, but these modules have almost exclusively resistive touch, You can connect them, depending on the model, via the GPIOs or (if available) directly via HDMI.', 152),
               ('HD44780 Displays', 'display', 5.0, 'In addition to touch screens, there are also pure character displays. The most common are 16Ã02 and 20Ã04 displays, which specifies the number of characters per line and amount of rows. Almost all of these displays have an HD44780 controller, which can be easily accessed with the Raspberry Pi.', 124),
               ('7 Segment Display', 'display', 3.0, '7 Segment displays are often used to display numbers and, as the name implies, have seven luminous segments, which can be addressed individually. In order not to occupy too many GPIOs, one usually takes a controller like the MAX7219. In addition to the usual 7 segment displays, there are also models, which contain 15 controllable segments and with it it is also possible to display letters (even if that does not look so nice).', 1256),
               ('MAX7219 LED Matrix', 'display', 5.0, 'The square 8Ã8 LED matrices are available in red and green. It is possible to control each individual LED with the help of the MAX7219 IC. In addition, many of these modules can be plugged together, resulting in a large dot display. The signal is sent via SPI. I have written a library, which letâs you easily control these matrices.', 126),
               ('Optical Fingerprint Sensor', 'input', 30.0, 'Fingerprint Sensor can be used to implement safety-relevant applications. For example, the fingerprints of different persons are stored and authorization rights are given to them. Electronic saves or door locks can be built. A password can also be requested in conjunction with a numpad. The interrogation of the sensor is surprisingly accurate and takes place by means of features. After reading or storing the imprint, it is even possible to export the imprint as an image.', 51),
               ('Arduino', 'microcontroller', 6.0, 'The Raspberry Pi can also be used as a micro-controller, but it has a lot more functions because it runs an operating system. A true micro-controller is e.g. the Arduino. It can, for example, also read analog sensors. The Arduino can also be operated very easily on and with the Raspberry Pi, e.g. via USB or 433 MHz or 2.4 GHz radio. Since Arduinos are cheaper than normal Raspberry Pis, they can either serve as extensions for the GPIOs or as an outdoor station for certain sensors whose data is transmitted wirelessly. As there are more projects for the Arduino than for the Raspberry Pi, you can also implement and run those projects on the Raspberry Pi (via the Arduino detour).', 127),
               ('ESP8266 NodeMCU', 'microcontroller', 4.0, 'The ESP8266 NodeMCU is a microcontroller that has a built-in Wifi module. Because of this and by its very low price, it is clearly more attractive than an Arduino. The programming takes place via the serial port can be done either via the Arduino IDE or other programs (LUA). If one has distributed a weather station or other IoT devices that are on the same WLAN network, you can send their data to a Raspberry Pi âmother stationâ via wifi. The ESP8266 is available in different versions, although the most favorable variant (ESP-01) has only two GPIO pins. Other models like the ESP-12 offer a lot more pins for a small extra charge.', 412),
               ('KeyPad / Numpad', 'input', 3.0, 'A numeric input field is required for vault or code lock projects. For this there are own modules, which look like a numpad on the PC keyboard. These modules are available in different sizes (3Ã4, 4Ã4, etc.) and can be read directly at the Raspberry Pi. By entering certain numerical codes / combinations, you can execute secret actions', 512),
               ('Magnet valve', 'other', 13.0, 'A solenoid valve is suitable for interrupting the flow of liquids or gases. A kind of âopenerâ can be built between two pipes or hoses. Ideally, magnetic valves are used, which are operated with 12 volts. All you need is an external power supply and a relay on the Raspberry Pi, which switches the solenoid.  You can use those valves e.g. in the outdoor area (keyword: automatic irrigation) or also in smaller projects such as intelligent coffeemakers, etc.', 517),
               ('Water Flowmeter', 'water sensor', 10.0, 'With the aid of water flow meters (Hall effect sensors), the amount of water flowing through the tube per minute / second can be determined at the Raspberry Pi. There are different sensors which have a higher accuracy or a higher flow rate and maximum water pressure. These measuring aids are particularly interesting in the outdoor and garden areas. For example, the rainfall of a thunderstorm can be determined (drainage channel) or the irrigation of the plants can be checked.', 518),
               ('MCP23017 Port Expander', 'expander', 4.0, 'The MCP 23017 device is an IO port expander. Because the Pi has only a limited number of GPIOs, these can easily run out for larger projects or multiple connected modules. A port expander is controlled by I2C and extends the number of IO pins. You have (per port expander) an additional 16 pins, which you can declare as input or output. You can also connect and control multiple port expanders at the same time.', 125),
               ('HX711 Weighing Sensor + Load Cell', 'sensor', 5.0, 'Using the HX711 sensor, the Raspberry Pi can also weigh items. This requires a LoadCell (US* | UK*), which must be connected and calibrated once. Depending on the model, the accuracy and the maximum weight to be measured will vary.', 51),
               ('ENC28J60 Ethernet module', 'internet', 4.0, 'If you call a Raspberry Pi Zero your own, you probably know the problem: Because there is only one (micro) USB port, an Internet connection is only per WiFi possible, because â unlike the Raspberry Pi 3 â it does not have an integrated WiFi adapter. If you would like to use another USB device, a USB hub is necessary. The ENC28J60 module can be used here: it is connected to the GPIOs and allows a wired Ethernet connection. Thus no external Wi-Fi stick is necessary and no USB hub is needed.', 213),
               ('Official Raspberry Pi Camera Module', 'camera', 20.0, 'In many Raspberry Pi projects, cameras are also used. In this case, customary USB webcams can be used, but their quality is often not very good and also it occupies a USB port. A better alternative is the official camera module of the Raspberry Pi Foundation, which can be directly connected via the CSI port. The module is available in two versions: With (green) and without (black) infrared filter. The lack of an infrared filter allows a higher light sensitivity, which results in better images at dusk / night.', 871),
               ('6DOF Robot Arm', 'servo/motor', 40.0, 'Multiple servos allow you to control a multi-axis robot arm with the Raspberry Pi. There are different versions, of which the most familiar is the one with 6 engines. Each individual servo can be individually controlled, resulting in a high degree of accuracy. Besides the servomotors, a driver board like the PCA9685 is very useful.', 12),
               ('Photoresistors', 'sensor', 1.0, 'In addition to conventional resistors and potentiometers, there are also photoresistors. These have a light-sensitive surface and have a different resistance value, depending on the light intensity. They can be used, for example, to detect day / night or to build light barriers.', 1678),
               ('WS2801B RGB LED Stripe', 'light', 20.0, 'WS2801 LED strips contain many controllable RGB LEDs, which can be addressed individually. Depending on the model, there are variants with 30/60/144 LEDs per meter. With these LED strips Ambilight projects can be implemented very well. In contrast to the cheaper WS2812B models (which have only one data line), the WS2801B RGB LED strips can be addressed directly from the Raspberry Pi, which means that no additional Arduino is required as an intermediate storage.', 51),
               ('WS2812 RGB LED Strip', 'light', 10.0, 'The WS2812 LED strips offer the advantage of a better price / performance ratio. However, either an Arduino must be used as an intermediate segment, or the onboard sound is deactivated, whereby this strip is also directly accessible. However, since the Raspberry Pi does not send real-time signals and the frequency is not so high, this strip is not suitable for all projects. However, the WS2812 offers some advantages.', 71);


INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('SOON', '2021-01-01', '100000', '100000', '100001', 30.0, '100001');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('SOON', '2021-01-03', '100001', '100001', '100001', 31.0, '100021');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('SOON', '2021-01-04', '100002', '100002', '100002', 33.0, '100012');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('SOON', '2021-01-05', '100003', '100003', '100003', 34.0, '100011');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('ARRIVING', '2021-01-06', '100004', '100004', '100004', 35.0, '100011');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('ARRIVING', '2021-01-07', '100005', '100005', '100005', 36.0, '100019');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('ARRIVING', '2021-01-08', '100006', '100006', '100006', 37.0, '100021');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('ARRIVING', '2021-01-09', '100007', '100007', '100007', 38.0, '100011');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('STORAGE', '2021-01-10', '100008', '100008', '100010', 293.0, '100031');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('STORAGE', '2021-01-11', '100009', '100009', '100011', 494.0, '100000');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('STORAGE', '2021-01-12', '100010', '100010', '100012', 120.0, '1000012');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('STORAGE', '2021-01-13', '100011', '100011', '100013', 948.0, '1000034');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('STORAGE', '2021-01-14', '100012', '100012', '100014', 568.0, '1000021');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('STORAGE', '2021-01-15', '100013', '100013', '100015', 482.0, '1000041');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('STORAGE', '2021-01-16', '100014', '100014', '100016', 392.0, '1000036');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('STORAGE', '2021-01-17', '100015', '100015', '100017', 8342.0, '1000027');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('STORAGE', '2021-01-18', '100016', '100016', '100018', 92382.0, '1000028');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('STORAGE', '2021-01-19', '100017', '100017', '100019', 223.0, '1000029');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('STORAGE', '2021-01-20', '100018', '100018', '100020', 934.0, '1000021');
INSERT INTO IOTUSER."ORDER" (STATUS, ORDERTIME, SHIPMENTID, PAYMENTID, USERID, TOTALPRICE, ORDERLIST) 
	VALUES ('STORAGE', '2021-01-21', '100019', '100019', '100021', 2345.0, '1000042');

INSERT INTO IOTUSER.PAYMENT("DATE", PAYMENTMETHOD, PAYMENTAMOUNT, ORDERID, CVV, CREDITNUM)
VALUES
    ('5/15/2021','visa',10.0,1,111,'1111 1111 1111 1111'),
    ('5/15/2021','google pay',3.0,1,123,'1111 1111 1111 1111'),
    ('5/15/2021','apple Pay',2.0,3,123,'1111 1111 1111 1111'),
    ('5/15/2021','visa',4.0,4,544,'1111 1111 1111 1111'),
    ('5/15/2021','visa',5.0,5,353,'1111 1111 1111 1111'),
    ('5/15/2021','google pay',6.0,6,543,'1111 1111 1111 1111'),
    ('5/15/2021','google pay',1.0,7,345,'1111 1111 1111 1111'),
    ('5/15/2021','google pay',2.0,8,765,'1111 1111 1111 1111'),
    ('5/15/2021','apple Pay',10.0,9,654,'1111 1111 1111 1111'),
    ('5/15/2021','apple Pay',15.0,10,456,'1111 1111 1111 1111'),
    ('5/15/2021','visa',16.0,11,654,'1111 1111 1111 1111'),
    ('5/15/2021','google pay',140,12,765,'1111 1111 1111 1111'),
    ('5/15/2021','apple Pay',20.0,13,765,'1111 1111 1111 1111'),
    ('5/15/2021','visa',15.0,14,456,'1111 1111 1111 1111'),
    ('5/15/2021','visa',18.0,15,345,'1111 1111 1111 1111'),
    ('5/15/2021','google pay',10.0,16,654,'1111 1111 1111 1111'),
    ('5/15/2021','google pay',14.0,17,234,'1111 1111 1111 1111'),
    ('5/15/2021','google pay',8.0,18,765,'1111 1111 1111 1111'),
    ('5/15/2021','apple Pay',5.0,19,252,'1111 1111 1111 1111'),
    ('5/15/2021','apple Pay',7.0,20,364,'1111 1111 1111 1111');


INSERT INTO IOTUSER.SHIPMENT(SHIPMENTID, UNITNUMBER, STREETNAME, SUBURB, POSTCODE, STATE, USERID, SHIPMENTDATE) VALUES
(1, '1', 'George', 'Hurstville', '2220', 'NSW', '1', '2021-05-18 17:51:19');
(2, '3', 'Forest', 'Hurstville', '2220', 'NSW', '1', '2021-05-18 17:51:19');
(3, '6', 'Tall', 'City', '2000', 'NSW', '1', '2021-05-18 17:51:19');
(4, '7', 'Jersy', 'Mascoy', '2210', 'NSW', '1', '2021-05-18 17:51:19');
(5, '5', 'Stoney', 'City', '2000', 'NSW', '1', '2021-05-18 17:51:19');
(6, '8', 'King', 'Bronte', '2100', 'NSW', '1', '2021-05-18 17:51:19');
(7, '14', 'George', 'Little Bay', '2110', 'NSW', '1', '2021-05-18 17:51:19');
(8, '9', 'Forest', 'City', '2000', 'NSW', '1', '2021-05-18 17:51:19');
(9, '5', 'Stoney', 'Hurstville', '2220', 'NSW', '1', '2021-05-18 17:51:19');
(10, '6', 'Tall', 'Hurstville', '2220', 'NSW', '1', '2021-05-18 17:51:19');
(11, '15', 'Jersy', 'Hurstville', '2220', 'NSW', '1', '2021-05-18 17:51:19');
(12, '13', 'George', 'Mascoy', '2210', 'NSW', '1', '2021-05-18 17:51:19');
(13, '6', 'Forest', 'Hurstville', '2220', 'NSW', '1', '2021-05-18 17:51:19');
(14, '17', 'George', 'Bronte', '2100', 'NSW', '1', '2021-05-18 17:51:19');
(15, '18', 'Jersy', 'Hurstville', '2220', 'NSW', '1', '2021-05-18 17:51:19');
(16, '19', 'George', 'Hurstville', '2220', 'NSW', '1', '2021-05-18 17:51:19');
(17, '12', 'Tall', 'City', '2000', 'NSW', '1', '2021-05-18 17:51:19');
(18, '14', 'Forest', 'Mascoy', '2210', 'NSW', '1', '2021-05-18 17:51:19');
(19, '16', 'King', 'Townhall', '1900', 'NSW', '1', '2021-05-18 17:51:19');
(20, '8', 'Jersy', 'Hurstville', '2220', 'NSW', '1', '2021-05-18 17:51:19');
