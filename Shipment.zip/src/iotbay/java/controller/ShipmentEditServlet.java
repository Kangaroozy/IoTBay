/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package iotbay.controller;

import iotbay.model.Payment;
import iotbay.model.Shipment;
import iotbay.model.dao.DBPaymentManager;
import iotbay.model.dao.DBShipmentManager;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author shu
 */
public class ShipmentEditServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        DBShipmentManager paManager = (DBShipmentManager) session.getAttribute("shipmentManager");
        int shipmentId = Integer.parseInt(request.getParameter("shipmentId"));

        try {
            Shipment shipment = paManager.findShipment(shipmentId);
            request.setAttribute("shipment", shipment);
            request.getRequestDispatcher("Update_Shipment.jsp").forward(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(ShipmentEditServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }
}