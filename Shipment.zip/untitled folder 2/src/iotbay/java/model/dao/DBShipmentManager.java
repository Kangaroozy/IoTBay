package iotbay.model.dao;

import iotbay.model.Shipment;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class DBShipmentManager {
    private Statement st;

    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public DBShipmentManager(Connection conn) throws SQLException {
        st = conn.createStatement();
    }

    public void saveShipment(Shipment shipment) throws SQLException {
        String sql = "INSERT INTO SHIPMENT (UNITNUMBER, STREETNAME, SUBURB, POSTCODE, STATE, USERID, SHIPMENTDATE) " +
                "VALUES (%s, '%s', '%s', '%s', '%s', '%s', '%s');";
        st.executeUpdate(String.format(sql,
                shipment.getUnitNumber(),
                shipment.getStreetName(),
                shipment.getSuburb(),
                shipment.getPostCode(),
                shipment.getState(),
                shipment.getUserid(),
                sdf.format(shipment.getShipmentDate())));
    }

    public List<Shipment> findShipmentHistory(String userid) throws SQLException {
        String sql = "SELECT * FROM SHIPMENT WHERE USERID = '" + userid + "';";
        ResultSet set = st.executeQuery(sql);
        List<Shipment> shipments = new ArrayList<>();
        while(set.next())
        {
            Shipment shipment = new Shipment();
            shipment.setShipmentID(set.getInt("SHIPMENTID"));
            shipment.setUnitNumber(set.getString("UNITNUMBER"));
            shipment.setStreetName(set.getString("STREETNAME"));
            shipment.setSuburb(set.getString("SUBURB"));
            shipment.setState(set.getString("STATE"));
            shipment.setUserid(set.getString("USERID"));
            shipment.setPostCode(set.getString("POSTCODE"));
            shipment.setShipmentDate(set.getDate("SHIPMENTDATE"));

            shipments.add(shipment);
        }

        set.close();
        return shipments;
    }

    public void deleteId(String shipmentId) throws SQLException {
        String sql = "DELETE FROM SHIPMENT WHERE SHIPMENTID = " + shipmentId + ";";
        st.executeUpdate(sql);
    }

    public Shipment findShipment(int shipmentId) throws SQLException {
        String sql = "SELECT * FROM SHIPMENT WHERE SHIPMENTID = " + shipmentId + ";";
        ResultSet set = st.executeQuery(sql);
        set.next();

        Shipment shipment = new Shipment();
        shipment.setShipmentID(set.getInt("SHIPMENTID"));
        shipment.setUnitNumber(set.getString("UNITNUMBER"));
        shipment.setStreetName(set.getString("STREETNAME"));
        shipment.setSuburb(set.getString("SUBURB"));
        shipment.setState(set.getString("STATE"));
        shipment.setUserid(set.getString("USERID"));
        shipment.setPostCode(set.getString("POSTCODE"));
        shipment.setShipmentDate(set.getDate("SHIPMENTDATE"));

        set.close();
        return shipment;
    }

    public void updateShipment(Shipment shipment) throws SQLException {
        String sql = "UPDATE SHIPMENT SET UNITNUMBER=%s, STREETNAME='%s', SUBURB='%s', POSTCODE='%s', STATE='%s' WHERE SHIPMENTID = %s";
        st.executeUpdate(String.format(sql,
                shipment.getUnitNumber(),
                shipment.getStreetName(),
                shipment.getSuburb(),
                shipment.getPostCode(),
                shipment.getState(),
                shipment.getShipmentID()));
    }
}
